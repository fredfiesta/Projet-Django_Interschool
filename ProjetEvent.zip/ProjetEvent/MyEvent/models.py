from datetime import date

import django.contrib.auth.models
from django.db import models

class Lieu(models.Model):
    nom = models.CharField(max_length=50)

class Event(models.Model):
    id = models.IntegerField
    nom = models.CharField(max_length=50)
    date = models.DateField()
    description = models.CharField(max_length=200)
    heure = models.DateTimeField()
    image = models.ImageField(blank=True, upload_to='event_images')
    Lieu = models.ForeignKey(Lieu, on_delete=models.CASCADE)


class Commentaire(models.Model):
    contenu = models.CharField(max_length=50)
    date = models.DateField()
    heure = models.DateTimeField()
    Event = models.ForeignKey(Event, on_delete=models.CASCADE)


class CommentaireLieu(models.Model):
    contenu = models.CharField(max_length=50)
    date = models.DateField()
    heure = models.DateTimeField()
    Lieu = models.ForeignKey(Lieu, on_delete=models.CASCADE)
