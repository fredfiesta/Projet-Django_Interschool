from datetime import date
import django.contrib.auth.models
from django.db import models
from django.contrib.auth.models import User, Group
from rest_framework import serializers


class UserSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = User
        fields = ['url', 'username', 'email', 'groups']


class GroupSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Group
        fields = ['url', 'name']


class Lieu(models.Model):
    nom = models.CharField(max_length=50)

class Event(models.Model):
    id = models.IntegerField
    nom = models.CharField(max_length=50)
    date = models.DateField()
    description = models.CharField(max_length=200)
    heure = models.DateTimeField()
    image = models.ImageField(blank=True, upload_to='event_images')
    Lieu = models.ForeignKey(Lieu, on_delete=models.CASCADE)

class Commentaire(models.Model):
    contenu = models.CharField(max_length=50)
    date = models.DateField()
    heure = models.DateTimeField()
    Event = models.ForeignKey(Event, on_delete=models.CASCADE)

class CommentaireLieu(models.Model):
    contenu = models.CharField(max_length=50)
    date = models.DateField()
    heure = models.DateTimeField()
    Lieu = models.ForeignKey(Lieu, on_delete=models.CASCADE)

class Participe(models.Model):
    Event = models.ForeignKey(Event, on_delete=models.CASCADE)
    User = models.ForeignKey(User, on_delete=models.CASCADE)