from . import models
from django.contrib.auth.models import User, Group
from rest_framework import serializers


class EventSerializers(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = models.Event
        fields = '__all__'  # ce qui yaura sur la vue


class LieuSerializers(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = models.Lieu
        fields = '__all__'


class CommentaireSerializers(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = models.Commentaire
        fields = '__all__'


class CommentaireLieuSerializers(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = models.Commentaire
        fields = '__all__'


class ParticipeSerializers(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = models.Participe
        fields = '__all__'


class UserSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = User
        fields = ['url', 'username', 'email', 'groups']


class GroupSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Group
        fields = ['url', 'name']


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(max_length=128, min_length=6, write_only=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']

    def create(self, validated_data):
        return User.objects.create_user(**validated_data)


class LoginSerializer(serializers.ModelSerializer):
    password = serializers.CharField(max_length=128, min_length=6, write_only=True)
    #token = serializers.CharField(max_length=255, read_only=True)

    class Meta:
        model = User
        fields = ('email', 'username', 'password')#,'token')
        #read_only_fields = ['token']

