from datetime import date
import django.contrib.auth.models
from django.core.files import File
from django.db import models
from django.contrib.auth.models import User, Group
from rest_framework import serializers
from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver
from rest_framework.authtoken.models import Token

import jwt
from django.conf import settings
from datetime import datetime, timedelta


class Lieu(models.Model):
    nom = models.CharField(max_length=50)

    def __str__(self):
        return str(self.nom)


class Event(models.Model):
    nom = models.CharField(max_length=50)
    date = models.DateField()
    description = models.CharField(max_length=200)
    heure = models.TimeField()
    image = models.ImageField(blank=True, upload_to='event_images')
    Lieu = models.ForeignKey(Lieu, on_delete=models.CASCADE)
    Createur = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.nom)


class Commentaire(models.Model):
    contenu = models.CharField(max_length=50)
    date = models.DateField()
    heure = models.DateTimeField()
    Event = models.ForeignKey(Event, on_delete=models.CASCADE)
    User = models.ForeignKey(User, on_delete=models.CASCADE)


class CommentaireLieu(models.Model):
    contenu = models.CharField(max_length=50)
    date = models.DateField()
    heure = models.DateTimeField()
    Lieu = models.ForeignKey(Lieu, on_delete=models.CASCADE)
    User = models.ForeignKey(User, on_delete=models.CASCADE)


class Participe(models.Model):
    Event = models.ForeignKey(Event, on_delete=models.CASCADE)
    User = models.ForeignKey(User, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('Event', 'User')


EMAIL_FIELD = 'email'
USERNAME_FIELD = 'email'
REQUIRED_FIELDS = ['username']


@property
def token(self):
    return jwt.encode({'username': self.username, 'email': self.email, 'exp': datetime.utcnow() + timedelta(hours=24)},
                      settings.SECRET_KEY, algorithm='HS256')
