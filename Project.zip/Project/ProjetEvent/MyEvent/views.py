from django.contrib.auth import authenticate
from django.contrib.sites.shortcuts import get_current_site
from django.http import HttpResponseRedirect
from django.shortcuts import render
from rest_framework import viewsets, permissions, status
from rest_framework.authentication import SessionAuthentication, BasicAuthentication, TokenAuthentication
from rest_framework.generics import GenericAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView


from .serializers import *
from rest_framework.authtoken.models import Token


class EventViewSet(viewsets.ModelViewSet):
    queryset = models.Event.objects.all()
    serializer_class = EventSerializers


class LieuViewSet(viewsets.ModelViewSet):
    queryset = models.Lieu.objects.all()
    serializer_class = LieuSerializers


class CommentaireViewSet(viewsets.ModelViewSet):
    queryset = models.Commentaire.objects.all()
    serializer_class = CommentaireSerializers


class CommentaireLieuViewSet(viewsets.ModelViewSet):
    queryset = models.CommentaireLieu.objects.all()
    serializer_class = CommentaireLieuSerializers


class UserViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = User.objects.all().order_by('-date_joined')
    serializer_class = UserSerializer
    #permission_classes = [permissions.IsAuthenticated]


class GroupViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Group.objects.all()
    serializer_class = GroupSerializer
    permission_classes = [permissions.IsAuthenticated]


class ParticipeViewSet(viewsets.ModelViewSet):
    queryset = models.Participe.objects.all()
    serializer_class = ParticipeSerializers


class registerAPIView(GenericAPIView):
    serializer_class = RegisterSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class loginAPIView(GenericAPIView):
    serializer_class = LoginSerializer

    def post(self, request):
        username = request.data.get("username", None)
        password = request.data.get("password", None)
        user = authenticate(username=username, password=password)
        if user:
            token, _ = Token.objects.get_or_create(user=user)
            serializer = self.serializer_class(user)
            return Response({"user":serializer.data,'token': token.key}, status=status.HTTP_200_OK)
        else:
            return Response({"error": "Invalid Credentials"}, status=status.HTTP_401_UNAUTHORIZED)


class AuthUserAPIView(GenericAPIView):
    authentication_classes = (TokenAuthentication,)
    permission_classes = [IsAuthenticated,]

    def get(self, request, format=None):
        content = {
            'url': str(request.build_absolute_uri())+"s".split('?')[0]+"/"+str(request.user.id)+"/",
            'name': str(request.user.username),  # `django.contrib.auth.User` instance.
            'email': str(request.user.email)
            #'auth': str(request.auth),  # None
        }
        return Response(content)

